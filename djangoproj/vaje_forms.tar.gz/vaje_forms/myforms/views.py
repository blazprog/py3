from django.shortcuts import render, get_object_or_404
from django.views.generic import View, ListView, UpdateView, CreateView
from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import SubjectForm, ExerciseForm, UserForm, UserProfileForm, LoginForm
from .models import Subject, Language, ExercisesModel
import myforms.exercise_parser as my_parser


# Create your views here.
class SubjectList(ListView):
    model = Subject
    context_object_name = "subject_list"
    template_name = "myforms/base.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data()

        lang = self.kwargs.get("language","ru")
        context["language"] = Language.objects.filter(language=lang).first()
        return context

    def get_queryset(self, **kwargs):
        lang = self.kwargs.get("language","ru")
        language = Language.objects.filter(language=lang).first()
        print(language)
        return Subject.objects.filter(language=language)



class SubjectCreateView(CreateView):

    form_class = SubjectForm
    template_name = "myforms/subject_form.html"

    def get_success_url(self, **kwargs):
        lang= self.kwargs.get("language")
        return reverse("subjects", kwargs={"language": lang})

    def get_context_data(self,**kwargs):
        context = super().get_context_data(**kwargs)
        lang= self.kwargs.get("language")
        language = Language.objects.filter(language=lang).first()
        context["language"] = language
        context["subject_list"] = Subject.objects.filter(language=language)
        context["action"] = reverse("subject_add", kwargs={"language": lang})
        return context

    def get_initial(self,**kwargs):
        lang=self.kwargs.get("language")
        language = Language.objects.filter(language=lang).first()
        return {
            "language": language,
        }

class ExerciseList(ListView):
    context_object_name = "exercise_list"
    template_name = "myforms/exercises.html"

    def get_queryset(self):
        subject_id = self.kwargs.get("subject")
        subject_obj = get_object_or_404(Subject, id = subject_id)
        return ExercisesModel.objects.filter(subject = subject_obj)

    def get_context_data(self, **kwargs):
        """context moram razširiti s podatki, ki jih potrbuje base.html.
        To je s spiskom tem za posamezen jezi
        V nasprotnem primeru, v stranskem pladnju ni podatkov.
        """
        subject_id = self.kwargs.get("subject")
        subject_obj = get_object_or_404(Subject, id = subject_id)
        context = super().get_context_data(**kwargs)
        context["language"] = subject_obj.language
        context["subject_list"] = Subject.objects.filter(language=subject_obj.language)
        return context


class ExerciseMixin:

    def get_success_url(self):
        return reverse("exercises",
                       kwargs = {"subject": self.object.subject.id,
                            "language" : self.object.subject.language.language })

    def get_context_data(self,**kwargs):
        context = super().get_context_data(**kwargs)
        lang = self.kwargs.get("language")
        language = Language.objects.filter(language=lang).first()
        context["language"] = language
        context["subject_list"] = Subject.objects.filter(language=language)
        if type(self) is ExerciseUpdateView:
            context["action"] = reverse("exercise_edit",
                                kwargs = {"pk":self.get_object().id, "language" : lang})
        else:
            context["action"] = reverse("exercise_add",
                                        kwargs = {"language": lang})
        return context


class ExerciseUpdateView(ExerciseMixin, UpdateView):
    model = ExercisesModel
    fields = ["language", "subject", "name", "exercise"]
    #form_class = ExerciseForm
    template_name = "myforms/exercise_form.html"


class ExerciseCreateView(ExerciseMixin, CreateView):
    model = ExercisesModel
    fields = ["language", "subject", "name", "exercise"]
    #form_class = ExerciseForm
    template_name = "myforms/exercise_form.html"

    def get_initial(self,**kwargs):
        lang=self.kwargs.get("language")
        language = Language.objects.filter(language=lang).first()
        return {
            "language": language,
        }


class ExerciseSolveView(View):
    def get(self, request, pk, language): #pk parameter defined in url
        exercise = get_object_or_404(ExercisesModel,pk=pk)
        context_dict = {}
        context_dict["exercise_name"] = exercise.name
        context_dict["exercise_id"] = exercise.id
        context_dict["language"] = exercise.language
        listDisplay, listCheck = my_parser.parse(exercise.exercise.strip())
        context_dict["exercise_parts"] = listDisplay
        context_dict["action"] = reverse("exercise_solve",
                kwargs = {'pk': exercise.id, 'language': exercise.language.language})

        context_dict["subject_list"] = Subject.objects.filter(language=exercise.language)
        return render(request,"myforms/exercise_solve.html", context_dict)

    def post(self, request, pk,  *args, **kwargs):
        exercise = get_object_or_404(ExercisesModel,pk=pk)
        listDisplay, listCheck = my_parser.parse(exercise.exercise.strip())
        i=0
        context_dict = {}
        for key in listCheck.keys():
            my_parser.markUserAnswer(key,request.POST[key],listDisplay)
        #Tu bi bilo bolj enostavno v context_dict postaviti exercise object
        context_dict["exercise_id"] = exercise.id
        context_dict["exercise_parts"] = listDisplay
        context_dict["exercise_name"] = exercise.name
        context_dict["language"] = exercise.language
        context_dict["subject_list"] = Subject.objects.filter(language=exercise.language)
        #add_translated_strings(context_dict,
        #                       "exercise_check.html",
        #                       exercise.language.language,
        #                       "Here_are_the_results_of", "Nazaj_na_vajo")
        return render(request,"myforms/exercise_check.html",context_dict)


def register(request, language):
    """Ta view realiziram kot funkcijo, ker uporablja dve formi,
    za enkrat še ne vem, kako to narediti z
    """
    registred = False

    if request.method == "POST":
        user_form = UserForm(data=request.POST)
        profile_form = UserProfileForm(data=request.POST)
        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save()
            #set password hashira password
            user.set_password(user.password)
            user.save()
            profile_form = profile_form.save(commit=False)
            profile_form.user = user
            profile_form.save()
            registred = True
            return HttpResponseRedirect(reverse("subjects", kwargs={"language" : language}))
    else:
        user_form = UserForm()
        profile_form = UserProfileForm()
    language_obj = Language.objects.filter(language=language).first()
    return render(request,"myforms/register.html",
                  {"user_form" : user_form,
                   "profile_form":profile_form,
                   "registred":registred,
                   "language" : language_obj})

class LoginView(View):
    def post(self, request, language):
        form = LoginForm(data=request.POST)
        username =  form.data["user"]
        password =  form.data["password"]
        user = authenticate(username=username, password=password)
        if user:
            # Is the account active? It could have been disabled.
            if user.is_active:
                login(request, user)
                return HttpResponseRedirect(reverse("subjects", kwargs={"language" : language}))
            else:
               return HttpResponse("Your account is disabled.")
        else:
            # Bad login details were provided. So we can't log the user in.
            return HttpResponse("Invalid login details supplied.")
            return render(request,"myforms/login.html",
                    {"form" : LoginForm(),"error_message": "Invalid login details"})

    def get(self, request, language):
        language_obj = Language.objects.filter(language=language).first()
        return render(request,"myforms/login.html", {"form" : LoginForm(),
                                                     "language": language_obj})



@login_required
def user_logout(request, language):
    logout(request)
    return HttpResponseRedirect(reverse("subjects", kwargs={"language" : language}))











