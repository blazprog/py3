__author__ = 'blazko'
from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit, Layout, Field,Div
from crispy_forms.bootstrap import FormActions
from .models import Subject, ExercisesModel, UserProfile, User

class SubjectForm(forms.ModelForm):
    class Meta:
        model = Subject
        fields = ['language', 'subject']

class ExerciseForm(forms.ModelForm):
    class Meta:
        model = ExercisesModel
        fields = ["language","subject","name","exercise"]


class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ("username", "email", "password")

class UserProfileForm(forms.ModelForm):

    class Meta:
        model = UserProfile
        fields = ("tutor",)

class LoginForm(forms.Form):
    user = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)