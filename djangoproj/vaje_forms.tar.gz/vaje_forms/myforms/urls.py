__author__ = 'blazko'

from django.conf.urls import patterns, include, url
from .views import (SubjectList,SubjectCreateView,
                    ExerciseList,ExerciseUpdateView,ExerciseCreateView,ExerciseSolveView,
                    register,LoginView, user_logout)


urlpatterns = patterns('',
       url(r"^subjects/(?P<language>\w\w)$",SubjectList.as_view(), name="subjects"),
       url(r"^exercises/(?P<language>\w\w)/(?P<subject>\d+)/$",ExerciseList.as_view(), name="exercises"),
       url(r"^exercise_edit/(?P<language>\w\w)/(?P<pk>\d+)/$",ExerciseUpdateView.as_view(), name="exercise_edit"),
       url(r"^exercise_solve/(?P<language>\w\w)/(?P<pk>\d+)/$",ExerciseSolveView.as_view(), name="exercise_solve"),
       url(r"^exercise_add/(?P<language>\w\w)$",ExerciseCreateView.as_view(), name="exercise_add"),
       url(r"^subject_add/(?P<language>\w\w)$",SubjectCreateView.as_view(), name="subject_add"),
       url(r"^register/(?P<language>\w\w)$",register, name="register"),
       url(r"^login/(?P<language>\w\w)$",LoginView.as_view(), name="login"),
       url(r"^logout/(?P<language>\w\w)$",user_logout, name="logout"),
       )